package psw.verapelle.service;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import psw.verapelle.DTO.CustomerDTO;
import psw.verapelle.entity.Customer;
import psw.verapelle.repository.CustomerRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    public List<CustomerDTO> getAllCustomers() {
        return customerRepository.findAll().stream().map(customer -> new CustomerDTO(customer.getId(), customer.getFirstName(),
                customer.getLastName(), customer.getDateOfBirth(), customer.getAddress(), customer.getEmail(), customer.getPhone())).collect(Collectors.toList());
    }

    public Optional<CustomerDTO> findCustomerById(Long id) {
        return customerRepository.findById(id).map(customer -> new CustomerDTO(customer.getId(), customer.getFirstName(),
                customer.getLastName(), customer.getDateOfBirth(), customer.getAddress(), customer.getEmail(), customer.getPhone()));
    }

    public Optional<Customer> findCustomerByEmail(String email) {
        return customerRepository.findByEmail(email);
    }

    //per keycloak
    public Customer saveCustomer(Customer customer) {
        Optional<Customer> existingCustomer = customerRepository.findByEmail(customer.getEmail());

        if (existingCustomer.isPresent()) {
            // L'utente esiste già, quindi aggiorniamo solo i campi necessari
            Customer updatedCustomer = existingCustomer.get();  // Prendo l'oggetto esistente
            updatedCustomer.setFirstName(customer.getFirstName());
            updatedCustomer.setLastName(customer.getLastName());
            updatedCustomer.setDateOfBirth(customer.getDateOfBirth());
            updatedCustomer.setAddress(customer.getAddress());
            updatedCustomer.setPhone(customer.getPhone());
            return customerRepository.save(updatedCustomer);
        } else {
            // L'utente non esiste, quindi lo creiamo
            return customerRepository.save(customer);
        }
    }

    //per controller
    public Customer saveCustomer(CustomerDTO customerDTO) {
        Optional<Customer> existingCustomer = customerRepository.findByEmail(customerDTO.getEmail());

        if (existingCustomer.isPresent()) {
            // L'utente esiste già, quindi aggiorniamo solo i campi necessari
            Customer updatedCustomer = existingCustomer.get();  // Prendo l'oggetto esistente
            updatedCustomer.setFirstName(customerDTO.getFirstName());
            updatedCustomer.setLastName(customerDTO.getLastName());
            updatedCustomer.setDateOfBirth(customerDTO.getDateOfBirth());
            updatedCustomer.setAddress(customerDTO.getAddress());
            updatedCustomer.setPhone(customerDTO.getPhone());
            updatedCustomer.setEmail(customerDTO.getEmail());
            return customerRepository.save(updatedCustomer);
        } else {
            // L'utente non esiste, quindi lo creiamo
            Customer newCustomer = new Customer();
            newCustomer.setFirstName(customerDTO.getFirstName());
            newCustomer.setLastName(customerDTO.getLastName());
            newCustomer.setDateOfBirth(customerDTO.getDateOfBirth());
            newCustomer.setAddress(customerDTO.getAddress());
            newCustomer.setPhone(customerDTO.getPhone());
            newCustomer.setEmail(customerDTO.getEmail());
            return customerRepository.save(newCustomer);
        }
    }
}
