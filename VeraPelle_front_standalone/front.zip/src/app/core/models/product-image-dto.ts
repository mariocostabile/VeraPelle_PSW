export interface ProductImageDTO {
  id: number;
  urlPath: string;
}
