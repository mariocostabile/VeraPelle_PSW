// src/app/core/models/customer-update.ts
export interface CustomerUpdate {
  dateOfBirth?: string;
  address?: string;
  phone?: string;
}
