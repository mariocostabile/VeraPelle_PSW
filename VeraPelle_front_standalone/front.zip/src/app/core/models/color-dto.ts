// src/app/core/models/color-dto.ts

export interface ColorDTO {
  id: number;
  name: string;
  hexCode: string;
}
